#ifndef CAT_THEME_STRATEGY_H
#define CAT_THEME_STRATEGY_H

#include "MessageProcessingStrategy.h"
#include <sstream>

/**
 * @brief Concrete Strategy: Cat themed friendly formatting
 */
class CatThemeStrategy : public MessageProcessingStrategy {
public:
    virtual std::string processMessage(const std::string& rawMessage, Users* fromUser, const std::string& roomName);
};

#endif
