#include "Dominiqu.h"

Dominiqu::Dominiqu(ChatRoom* room) : Users(room, "Dominiqu"){}