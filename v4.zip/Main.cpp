#include "CtrlCat.h"
#include "Dogorithm.h"
#include "Users.h"
#include "ChatRoom.h"
#include "Nathan.h"
#include "Dominiqu.h"
#include "Luyanda.h"
#include "Command.h"
#include "SendMessageCommand.h"
#include "SaveMessageCommand.h"
#include "UserIterator.h"
#include "MessageIterator.h"
#include "CatThemeStrategy.h"
#include "DogThemeStrategy.h"

#include <string>
#include <vector>
#include <iostream>

using namespace std;

void demonstratePermissionSystem();
void demonstrateTemplateMethodPattern();
void demonstrateCommandPattern();
void demonstrateMediatorPattern();
void demonstrateIteratorPattern();
void demonstrateStrategyPattern();

int main()
{
    cout << " Welcome to PetSpace - Advanced Chat System! " << endl;
    cout << "===================================================" << endl;
    cout << "Demonstrating Mediator, Template Method, Command, and Iterator Patterns" << endl;
    cout << "with Advanced Permission System and Enhanced Features" << endl;
    cout << "===================================================" << endl;

    demonstrateMediatorPattern();
    demonstrateTemplateMethodPattern();
    demonstrateCommandPattern();
    demonstrateIteratorPattern();
    demonstrateStrategyPattern();
    demonstratePermissionSystem();

    cout << "\n All Design Patterns Successfully Demonstrated! " << endl;
    cout << "====================================================" << endl;
    cout << "• Mediator: Chat rooms mediate all communication between users" << endl;
    cout << "• Template Method: Consistent 8-step message handling workflow" << endl;
    cout << "• Command: Encapsulated message operations with queuing" << endl;
    cout << "• Iterator: Safe traversal of users and chat history" << endl;
    cout << "• Strategy: Pluggable message formatting / enrichment per room" << endl;
    cout << "• Advanced Permissions: Role-based access control system" << endl;
    cout << "• Enhanced PostProcessing: Rich user engagement features" << endl;

    return 0;
}

void demonstrateMediatorPattern()
{
    cout << "\n 1. MEDIATOR PATTERN DEMONSTRATION" << endl;
    cout << "====================================" << endl;
    
  
    CtrlCat ctrlCat;
    Dogorithm dogorithm;
    
   
    Nathan nate(&ctrlCat);
    Dominiqu dom(&dogorithm);
    Luyanda luy(&dogorithm);
    
    
    ctrlCat.registerUser(&nate);
    dogorithm.registerUser(&dom);
    dogorithm.registerUser(&luy);
    
   
    dogorithm.registerUser(&nate);
    
    cout << " Chat rooms created: CtrlCat (cat-themed), Dogorithm (algorithm-focused)" << endl;
    cout << " Users registered:" << endl;
    cout << "   • Nathan → CtrlCat AND Dogorithm (multi-room user) " << endl;
    cout << "   • Dominiqu → Dogorithm only" << endl;
    cout << "   • Luyanda → Dogorithm only" << endl;
    cout << " All communication goes through ChatRoom mediators!" << endl;
    
    cout << "\n Mediated Communication:" << endl;
    
    cout << "\n--- Nathan posting in CtrlCat ---" << endl;
    nate.send("Hello everyone! I need help with debugging some code", &ctrlCat);
    
    cout << "\n--- Nathan posting in Dogorithm (same user, different room) ---" << endl;
    nate.setPermissionLevel(3);
    nate.send("I also want to discuss algorithm optimization techniques here", &dogorithm);
    
    cout << "\n--- Other users in Dogorithm ---" << endl;
    dom.setPermissionLevel(3);
    dom.send("Let's discuss the optimal search algorithm for this problem", &dogorithm);
    luy.setPermissionLevel(3); 
    luy.send("I found an efficient binary tree implementation!", &dogorithm);
}

void demonstrateTemplateMethodPattern()
{
    cout << "\n 2. TEMPLATE METHOD PATTERN DEMONSTRATION" << endl;
    cout << "============================================" << endl;
    
    CtrlCat ctrlCat;
    Dogorithm dogorithm;
    Nathan nate(&ctrlCat);
    Dominiqu dom(&dogorithm);
    
    ctrlCat.registerUser(&nate);
    dogorithm.registerUser(&dom);
    dogorithm.registerUser(&nate); // Nathan in both rooms for this demo too
    
    cout << " Template Method defines 8-step message handling workflow:" << endl;
    cout << "1. Validate message content and sender" << endl;
    cout << "2. Check user permissions" << endl;
    cout << "3. Pre-process message (Strategy pattern integration)" << endl;
    cout << "4. Broadcast message to all users" << endl;
    cout << "5. Save message to history" << endl;
    cout << "6. Log activity for audit trail" << endl;
    cout << "7. Perform post-processing actions" << endl;
    cout << "8. Update user statistics" << endl;
    
    cout << "\n Each room customizes validation, logging, and post-actions:" << endl;
    
    cout << "\n--- CtrlCat Room (Positive, Welcoming) ---" << endl;
    nate.send("I found a bug in my code! Can someone help debug this function?", &ctrlCat);
    
    cout << "\n--- Dogorithm Room (Technical, Algorithm-focused) ---" << endl;
    dom.setPermissionLevel(3); 
    dom.send("This recursive search algorithm has O(log n) complexity for binary trees", &dogorithm);
    
    cout << "\n--- Nathan posting in Dogorithm (same user, different room behavior) ---" << endl;
    nate.setPermissionLevel(3); 
    nate.send("I want to contribute to algorithm discussions too!", &dogorithm);
    
    cout << "\n🔍 Testing Template Method Validation:" << endl;
    cout << "--- Testing CtrlCat validation (should reject negative content) ---" << endl;
    nate.send("This code is stupid and dumb!", &ctrlCat);
    
    cout << "\n--- Testing Dogorithm validation (should accept technical content) ---" << endl;
    dom.send("Let's optimize this sorting algorithm for better performance", &dogorithm);
}

void demonstrateCommandPattern()
{
    cout << "\n 3. COMMAND PATTERN DEMONSTRATION" << endl;
    cout << "===================================" << endl;
    
    CtrlCat ctrlCat;
    Nathan nate(&ctrlCat);
    ctrlCat.registerUser(&nate);
    
    cout << " Command Pattern Components:" << endl;
    cout << "• Command Interface: Abstract Command with execute()" << endl;
    cout << "• Concrete Commands: SendMessageCommand, SaveMessageCommand" << endl;
    cout << "• Invoker: Users class (manages command queue)" << endl;
    cout << "• Receiver: ChatRoom (processes operations)" << endl;
    
    cout << "\n Creating individual commands manually:" << endl;
    
    SendMessageCommand* sendCmd = new SendMessageCommand(&ctrlCat, &nate, "This message uses explicit Command pattern!");
    SaveMessageCommand* saveCmd = new SaveMessageCommand(&ctrlCat, &nate, "This is a saved command message!");

    cout << " SendMessageCommand created" << endl;
    cout << " SaveMessageCommand created" << endl;

    cout << "\n Adding commands to user's queue:" << endl;
    nate.addCommand(sendCmd);
    nate.addCommand(saveCmd);
    
    cout << " Commands added to Nathan's command queue" << endl;
    
    cout << "\n Executing all queued commands:" << endl;
    nate.executeAll();
    
    cout << "\n Commands demonstrate:" << endl;
    cout << "• Encapsulation: Operations wrapped as objects" << endl;
    cout << "• Queuing: Commands can be stored and executed later" << endl;
    cout << "• Undo potential: Commands can be reversed (if implemented)" << endl;
    cout << "• Macro commands: Multiple commands can be batched" << endl;
}

void demonstratePermissionSystem()
{
    cout << "\n 4. ADVANCED PERMISSION SYSTEM DEMONSTRATION" << endl;
    cout << "===============================================" << endl;
    
    CtrlCat ctrlCat;
    Dogorithm dogorithm;
    Nathan nate(&ctrlCat);
    Dominiqu dom(&dogorithm);
    Luyanda luy(&dogorithm);
    
    ctrlCat.registerUser(&nate);
    dogorithm.registerUser(&dom);
    dogorithm.registerUser(&luy);
    dogorithm.registerUser(&nate); 
    
    cout << " Permission Levels:" << endl;
    cout << "1 = Guest (limited access)" << endl;
    cout << "2 = Member (standard access)" << endl;
    cout << "3 = Moderator (enhanced access)" << endl;
    cout << "4 = Admin (full access)" << endl;
    
    cout << "\n Current user permissions:" << endl;
    cout << "Nathan: Level " << nate.getPermissionLevel() << " (Member)" << endl;
    cout << "Dominiqu: Level " << dom.getPermissionLevel() << " (Member)" << endl;
    cout << "Luyanda: Level " << luy.getPermissionLevel() << " (Member)" << endl;
    
    cout << "\n Testing permission scenarios:" << endl;
    
    cout << "\n--- Scenario 1: Guest trying to post in CtrlCat ---" << endl;
    nate.setPermissionLevel(1);
    nate.send("I'm a guest trying to post", &ctrlCat);
    
    cout << "\n--- Scenario 2: Member posting in CtrlCat (should work) ---" << endl;
    nate.setPermissionLevel(2); 
    nate.send("Now I'm a member posting successfully!", &ctrlCat);
    
    cout << "\n--- Scenario 3: Member trying to post in Dogorithm (requires Moderator) ---" << endl;
    dom.setPermissionLevel(2); 
    dom.send("I'm trying to discuss algorithms as a member", &dogorithm);
    
    cout << "\n--- Scenario 4: Moderator posting in Dogorithm (should work) ---" << endl;
    dom.setPermissionLevel(3); 
    dom.send("Now I'm a moderator discussing advanced algorithm optimization techniques", &dogorithm);
    
    cout << "\n--- Scenario 5: Testing mute functionality ---" << endl;
    luy.setMuted(true);
    luy.send("This message should be blocked because I'm muted", &dogorithm);
    
    cout << "\n--- Scenario 6: Admin with full access ---" << endl;
    luy.setMuted(false);
    luy.setPermissionLevel(4);
    luy.send("I'm an admin with unlimited access to all features", &dogorithm);
    
    cout << "\n--- Scenario 7: Multi-room user (Nathan in both CtrlCat and Dogorithm) ---" << endl;
    nate.setPermissionLevel(3);
    cout << "Nathan posting in CtrlCat:" << endl;
    nate.send("Sharing tips in the friendly cat community!", &ctrlCat);
    cout << "Nathan posting in Dogorithm:" << endl;
    nate.send("Contributing to technical algorithm discussions!", &dogorithm);
    
    cout << "\n Permission System Features Demonstrated:" << endl;
    cout << "• Role-based access control" << endl;
    cout << "• Different requirements per room" << endl;
    cout << "• Mute functionality" << endl;
    cout << "• Message count tracking and limits" << endl;
    cout << "• Spam protection mechanisms" << endl;
    cout << "• Dynamic permission level changes" << endl;
    
    cout << "\n Final Statistics:" << endl;
    cout << "Nathan sent " << nate.getMessageCount() << " messages" << endl;
    cout << "Dominiqu sent " << dom.getMessageCount() << " messages" << endl;
    cout << "Luyanda sent " << luy.getMessageCount() << " messages" << endl;
    
    cout << "\n Chat History Summary:" << endl;
    cout << "CtrlCat has " << ctrlCat.getChatHistory().size() << " messages" << endl;
    cout << "Dogorithm has " << dogorithm.getChatHistory().size() << " messages" << endl;
}

void demonstrateIteratorPattern()
{
    cout << "-------------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << "====================================" << endl;
    cout << "====================================" << endl;
    cout << "4. ITERATOR PATTERN DEMONSTRATION" << endl;
    cout << "====================================" << endl;
    cout << "====================================" << endl;
    
    //the setup of the chat rooms and its users each with different permissions
    //chatrooms
    CtrlCat ctrlCat;
    Dogorithm dogorithm;
    //users
    Nathan nate(&ctrlCat);
    Dominiqu dom(&dogorithm);
    Luyanda luy(&dogorithm);
    
    
    nate.setPermissionLevel(2);             //member
    dom.setPermissionLevel(3);              //moderator  
    luy.setPermissionLevel(4);              //admin
    
    ctrlCat.registerUser(&nate);
    dogorithm.registerUser(&dom);
    dogorithm.registerUser(&luy);
    dogorithm.registerUser(&nate);      //nate is in both chatrooms
    
    cout << "\n Sample messages for iterator testing:" << endl;
    nate.send("Hello CtrlCat ppls, i say lebron is the best.", &ctrlCat);
    dom.send("Oh nah, lebron?! maybe yea, but what about jordan boss?", &dogorithm);
    luy.send("what about curry guys, hes the goat.", &dogorithm);
    nate.send("but bron is 40 dropping 40.", &dogorithm);
    nate.send("look at his stats for the past2 years!", &ctrlCat);
    dom.send("ahh guys, yk what lets just agree to disagree.", &dogorithm);
    
    cout << "6 messages were made across both chat rooms\n" << endl;
    


    // === USER ITERATOR TESTING ===
    cout << " USER ITERATOR TESTING" << endl;
    cout << "========================" << endl;
    
    cout << "\n--- Testing Forward User Iteration in Dogorithm ---" << endl;
    UserIterator* userIter = dogorithm.createUserIterator();
    cout << "Total users in Dogorithm: " << userIter->getTotalUsers() << endl;
    
    cout << "Iterating through all users:" << endl;
    int userCount = 1;
    while (userIter->hasNext()) {
        Users* user = userIter->next();
        if (user != nullptr) {
            cout << "  " << userCount << ". " << user->getName() 
                 << " (Level " << user->getPermissionLevel() << ")" << endl;
            userCount = userCount + 1;
        }
    }
    
    // cout << "\n--- Testing User Iterator Reset and Current ---" << endl;
    // userIter->reset();
    // cout << "After reset, current user: " << userIter->current()->getName() << endl;
    // cout << "Is iterator at start? " << (userIter->isDone() ? "No" : "Yes") << endl;
    
    // cout << "\n--- Testing Permission Level Filtering ---" << endl;
    // userIter->reset();
    // cout << "Finding users with Moderator level (3):" << endl;
    // std::vector<Users*> moderators = userIter->getUsersByPermissionLevel(3);
    // for (Users* mod : moderators) {
    //     cout << "  • " << mod->getName() << " (Moderator)" << endl;
    // }
    
    // cout << "Finding users with Admin level (4):" << endl;
    // std::vector<Users*> admins = userIter->getUsersByPermissionLevel(4);
    // for (Users* admin : admins) {
    //     cout << "  • " << admin->getName() << " (Admin)" << endl;
    // }
    
    // cout << "\n--- Testing Dynamic Permission Search ---" << endl;
    // userIter->reset();
    // Users* foundUser = userIter->findUserWithPermissionLevel(4);
    // if (foundUser != nullptr) {
    //     cout << "Found admin user: " << foundUser->getName() << endl;
    // }
    
    delete userIter;
    
    // === MESSAGE ITERATOR TESTING ===
    cout << "\n MESSAGE ITERATOR TESTING" << endl;
    cout << "============================" << endl;
    
    cout << "\n--- Testing Forward Message Iteration in Dogorithm ---" << endl;
    MessageIterator* msgIter = dogorithm.createMessageIterator();
    cout << "Total messages in Dogorithm: " << msgIter->getTotalMessages() << endl;
    
    cout << "All messages (chronological order):" << endl;
    int msgCount = 1;
    while (msgIter->hasNext()) {
        std::string* message = msgIter->next();
        if (message != nullptr) {
            cout << "  " << msgCount << ". " << *message << endl;
            msgCount = msgCount + 1;
        }
    }
    
    cout << "\n--- Testing Reverse Message Iteration ---" << endl;
    MessageIterator* reverseMsgIter = dogorithm.createMessageIterator(true);
    cout << "Messages in reverse order (newest first):" << endl;
    msgCount = 1;
    while (reverseMsgIter->hasNext()) {
        std::string* message = reverseMsgIter->next();
        if (message != nullptr) {
            cout << "  " << msgCount << ". " << *message << endl;
            msgCount = msgCount + 1;
        }
    }
    
    cout << "\n--- Testing Message Search Functionality ---" << endl;
    msgIter->reset();
    std::string* foundMsg = msgIter->findMessageContaining("curry");
    if (foundMsg != nullptr) {
        cout << "Found message containing 'algorithm': " << *foundMsg << endl;
    }
    
    msgIter->reset();
    foundMsg = msgIter->findMessageContaining("optimization");
    if (foundMsg != nullptr) {
        cout << "Found message containing 'optimization': " << *foundMsg << endl;
    }
    
    cout << "\n--- Testing User-Specific Message Filtering ---" << endl;
    std::vector<std::string> dominiquMessages = msgIter->getMessagesByUser("Dominiqu");
    cout << "Messages from Dominiqu (" << dominiquMessages.size() << " total):" << endl;
    for (const std::string& msg : dominiquMessages) {
        cout << "  • " << msg << endl;
    }
    
    std::vector<std::string> nathanMessages = msgIter->getMessagesByUser("Nathan");
    cout << "Messages from Nathan (" << nathanMessages.size() << " total):" << endl;
    for (const std::string& msg : nathanMessages) {
        cout << "  • " << msg << endl;
    }
    
    cout << "\n--- Testing Range-Based Message Retrieval ---" << endl;
    std::vector<std::string> rangeMessages = msgIter->getMessagesInRange(0, 3);
    cout << "First 3 messages:" << endl;
    for (size_t i = 0; i < rangeMessages.size(); i++) {
        cout << "  " << (i+1) << ". " << rangeMessages[i] << endl;
    }
    
    cout << "\n--- Testing Recent Messages Functionality ---" << endl;
    std::vector<std::string> recentMessages = msgIter->getRecentMessages(2);
    cout << "Last 2 messages:" << endl;
    for (size_t i = 0; i < recentMessages.size(); i++) {
        cout << "  " << (i+1) << ". " << recentMessages[i] << endl;
    }
    
    cout << "\n--- Testing Iterator Mode Switching ---" << endl;
    msgIter->reset();
    cout << "Forward mode - First message: " << *msgIter->current() << endl;
    msgIter->setReverseMode(true);
    cout << "Reverse mode - First message: " << *msgIter->current() << endl;
    
    delete msgIter;
    delete reverseMsgIter;


    
    
    // === CROSS-ROOM ITERATOR TESTING ===
    cout << "\n CROSS-ROOM ITERATOR TESTING" << endl;
    cout << "===============================" << endl;
    
    cout << "\n--- Comparing Chat Histories Between Rooms ---" << endl;
    MessageIterator* ctrlCatIter = ctrlCat.createMessageIterator();
    MessageIterator* dogorithmIter = dogorithm.createMessageIterator();
    
    cout << "CtrlCat messages (" << ctrlCatIter->getTotalMessages() << " total):" << endl;
    int ctrlCatCount = 1;
    while (ctrlCatIter->hasNext()) {
        std::string* message = ctrlCatIter->next();
        if (message != nullptr) {
            cout << "  " << ctrlCatCount << ". " << *message << endl;
            ctrlCatCount++;
        }
    }
    
    cout << "\nDogorithm messages (" << dogorithmIter->getTotalMessages() << " total):" << endl;
    int dogorithmCount = 1;
    dogorithmIter->reset();
    while (dogorithmIter->hasNext()) {
        std::string* message = dogorithmIter->next();
        if (message != nullptr) {
            cout << "  " << dogorithmCount << ". " << *message << endl;
            dogorithmCount++;
        }
    }
    
    cout << "\n--- Nathan's Multi-Room Message Analysis ---" << endl;
    std::vector<std::string> nathanCtrlCat = ctrlCatIter->getMessagesByUser("Nathan");
    std::vector<std::string> nathanDogorithm = dogorithmIter->getMessagesByUser("Nathan");
    
    cout << "Nathan's messages in CtrlCat (" << nathanCtrlCat.size() << "):" << endl;
    for (const std::string& msg : nathanCtrlCat) {
        cout << "  • " << msg << endl;
    }
    
    cout << "Nathan's messages in Dogorithm (" << nathanDogorithm.size() << "):" << endl;
    for (const std::string& msg : nathanDogorithm) {
        cout << "  • " << msg << endl;
    }
    
    delete ctrlCatIter;
    delete dogorithmIter;
}

void demonstrateStrategyPattern()
{
    cout << "========================================================" << endl;
    cout << "========================================================" << endl;
    cout << " 5. STRATEGY PATTERN (Message Processing) DEMONSTRATION" << endl;
    cout << "========================================================" << endl;
    cout << "========================================================" << endl;

    CtrlCat ctrlCat;          // Has CatThemeStrategy by default
    Dogorithm dogorithm;      // Has DogThemeStrategy by default
    Nathan nate(&ctrlCat);
    Dominiqu dom(&dogorithm);

    ctrlCat.registerUser(&nate);
    dogorithm.registerUser(&dom);
    dogorithm.registerUser(&nate); // multi-room user

    nate.setPermissionLevel(3);
    dom.setPermissionLevel(3);

    cout << "\nDefault strategies applied automatically by concrete room constructors:" << endl;
    nate.send("help me refactor this recursive function for better efficiency", &ctrlCat);
    dom.send("Analyzing O(n log n) complexity of tree sort optimize performance", &dogorithm);

    cout << "\nSwitching Dogorithm room to CatThemeStrategy at runtime (demonstrating hot swap):" << endl;
    // Reuse cat strategy instance just for demo (no delete to keep simple; ideally manage ownership smartly)
    dogorithm.setMessageProcessingStrategy(new CatThemeStrategy());
    dom.send("recursive tree traversal now has friendly cat formatting", &dogorithm);

    cout << "\nSwitching CtrlCat room to DogThemeStrategy to show technical tagging in friendly room:" << endl;
    ctrlCat.setMessageProcessingStrategy(new DogThemeStrategy());
    nate.send("loop optimize O(n) vs O(n log n) discussion inside cat room", &ctrlCat);

    cout << "\nStrategy Pattern Benefits Demonstrated:" << endl;
    cout << "• Open/Closed: New formatting behaviors via new strategy classes" << endl;
    cout << "• Single Responsibility: ChatRoom no longer hardcodes formatting rules" << endl;
    cout << "• Runtime Flexibility: Swapped strategies without changing user / room classes" << endl;
    cout << "• Reuse: Same strategy reused across different room types" << endl;
}