#include "MessageIterator.h"

/**
 * @file MessageIterator.cpp
 * @brief Implementation of MessageIterator concrete iterator
 * @author 2Amigos
 * @date 2025-09-29
 */

/**
 * @brief Constructor for MessageIterator
 * 
 * Initializes the iterator with a pointer to the message collection
 * and sets up iteration mode (forward or reverse).
 * 
 * @param messages Pointer to vector of messages to iterate over
 * @param reverse Whether to iterate in reverse order (newest first)
 * 
 * @details Initialization Logic:
 * - Forward mode: start at index 0
 * - Reverse mode: start at last valid index
 * - Null pointer safety with empty vector creation
 */
MessageIterator::MessageIterator(std::vector<std::string>* messages, bool reverse) 
    : messageList(messages), reverseMode(reverse) 
{
    if (messageList == nullptr) {
        messageList = new std::vector<std::string>(); // Create empty vector for safety
    }
    
    if (reverseMode && !messageList->empty()) {
        currentIndex = messageList->size() - 1;
    } else {
        currentIndex = 0;
    }
}

/**
 * @brief Destructor for MessageIterator
 * 
 * Cleans up resources. The iterator does not own the message collection.
 */
MessageIterator::~MessageIterator() 
{
    // Iterator doesn't own the message list
}

/**
 * @brief Check if there are more messages to iterate over
 * 
 * Handles both forward and reverse iteration modes with proper
 * bounds checking and underflow protection.
 * 
 * @return true if there are more messages, false if at end
 * 
 * @details Bounds Checking:
 * - Forward mode: currentIndex < size()
 * - Reverse mode: currentIndex is valid (handles size_t underflow)
 * - Empty collection safety
 */
bool MessageIterator::hasNext() 
{
    if (messageList == nullptr || messageList->empty()) {
        return false;
    }
    
    if (reverseMode) {
        // In reverse mode, we're done when currentIndex would underflow
        return currentIndex < messageList->size(); // This handles underflow safety
    } else {
        // Forward mode
        return currentIndex < messageList->size();
    }
}

/**
 * @brief Get the next message and advance the iterator
 * 
 * Returns the current message and advances the iterator according
 * to the iteration mode (forward or reverse).
 * 
 * @return Pointer to the next message, nullptr if at end
 * 
 * @details Advancement Logic:
 * - Forward mode: increment currentIndex
 * - Reverse mode: decrement currentIndex (with underflow protection)
 * - Bounds checking for safe access
 * 
 * @note Handles size_t underflow in reverse mode safely
 */
std::string* MessageIterator::next() 
{
    if (!hasNext()) {
        return nullptr;
    }
    
    std::string* message = &((*messageList)[currentIndex]);
    
    if (reverseMode) {
        if (currentIndex == 0) {
            // Set to invalid value to indicate end (size_t underflow protection)
            currentIndex = messageList->size();
        } else {
            currentIndex--;
        }
    } else {
        currentIndex++;
    }
    
    return message;
}

/**
 * @brief Reset iterator to the beginning of iteration
 * 
 * Resets the iterator to start position based on iteration mode.
 * Forward mode starts at 0, reverse mode starts at last index.
 */
void MessageIterator::reset() 
{
    if (messageList == nullptr || messageList->empty()) {
        currentIndex = 0;
        return;
    }
    
    if (reverseMode) {
        currentIndex = messageList->size() - 1;
    } else {
        currentIndex = 0;
    }
}

/**
 * @brief Get current message without advancing the iterator
 * 
 * Returns the message at current position without modifying iterator state.
 * Useful for peek operations and examination without consumption.
 * 
 * @return Pointer to current message, nullptr if at end
 */
std::string* MessageIterator::current() 
{
    if (!hasNext()) {
        return nullptr;
    }
    
    return &((*messageList)[currentIndex]);
}

/**
 * @brief Check if iterator has reached the end
 * 
 * Provides semantic clarity for iteration termination checks.
 * 
 * @return true if iterator is at end, false if more elements exist
 */
bool MessageIterator::isDone() 
{
    return !hasNext();
}

/**
 * @brief Get total number of messages in the collection
 * 
 * Returns collection size without affecting iterator state.
 * 
 * @return Total number of messages
 */
size_t MessageIterator::getTotalMessages() 
{
    if (messageList == nullptr) {
        return 0;
    }
    return messageList->size();
}

/**
 * @brief Switch between forward and reverse iteration modes
 * 
 * Changes the iteration direction and resets the iterator to
 * the appropriate starting position for the new mode.
 * 
 * @param reverse true for reverse iteration, false for forward
 * 
 * @note Automatically resets iterator position for new mode
 * @note Safe to call during iteration
 */
void MessageIterator::setReverseMode(bool reverse) 
{
    reverseMode = reverse;
    reset(); // Reset to appropriate starting position
}

/**
 * @brief Find next message containing specific text
 * 
 * Searches from current position for a message containing the
 * specified text. Advances iterator to found message.
 * 
 * @param searchText Text to search for in messages
 * @return Pointer to message containing text, nullptr if not found
 * 
 * @details Search Process:
 * 1. Continue from current position
 * 2. Check each message for substring match
 * 3. Return first match found
 * 4. Update iterator position to found message
 * 
 * @note Case-sensitive search
 * @note Modifies iterator position to found message
 * @note Returns nullptr if no match found
 */
std::string* MessageIterator::findMessageContaining(const std::string& searchText) 
{
    while (hasNext()) {
        std::string* message = current();
        if (message != nullptr && message->find(searchText) != std::string::npos) {
            next(); // Advance to this position
            return message;
        }
        next(); // Move to next message
    }
    return nullptr; // No message found containing the text
}

/**
 * @brief Get all messages from a specific user
 * 
 * Performs complete collection traversal to find all messages
 * from the specified user. Preserves iterator state.
 * 
 * @param username Name of user to filter messages by
 * @return Vector of messages from specified user
 * 
 * @details Filtering Process:
 * 1. Save current iterator state
 * 2. Reset and traverse entire collection
 * 3. Match messages starting with "username:"
 * 4. Collect all matching messages
 * 5. Restore original iterator state
 * 
 * @note Preserves iterator position after operation
 * @note Returns empty vector if no messages found
 * @note Matches messages with format "username: message"
 */
std::vector<std::string> MessageIterator::getMessagesByUser(const std::string& username) 
{
    std::vector<std::string> userMessages;
    
    // Save current state
    size_t originalIndex = currentIndex;
    bool originalReverseMode = reverseMode;
    
    // Reset to forward mode for consistent traversal
    reverseMode = false;
    reset();
    
    while (hasNext()) {
        std::string* message = next();
        if (message != nullptr) {
            // Check if message starts with "username:"
            std::string searchPattern = username + ":";
            if (message->substr(0, searchPattern.length()) == searchPattern) {
                userMessages.push_back(*message);
            }
        }
    }
    
    // Restore original state
    reverseMode = originalReverseMode;
    currentIndex = originalIndex;
    
    return userMessages;
}

/**
 * @brief Get messages within a specific range
 * 
 * Extracts messages from startIndex (inclusive) to endIndex (exclusive).
 * Provides bounds checking and safe range extraction.
 * 
 * @param startIndex Starting index (inclusive)
 * @param endIndex Ending index (exclusive)
 * @return Vector of messages in specified range
 * 
 * @details Range Validation:
 * - Clamps indices to valid collection bounds
 * - Handles invalid ranges gracefully
 * - Returns empty vector for invalid ranges
 * - Preserves iterator state
 * 
 * @note Does not modify iterator position
 * @note Returns empty vector for invalid ranges
 * @note Performs bounds checking for safety
 */
std::vector<std::string> MessageIterator::getMessagesInRange(size_t startIndex, size_t endIndex) 
{
    std::vector<std::string> rangeMessages;
    
    if (messageList == nullptr || startIndex >= endIndex || 
        startIndex >= messageList->size()) {
        return rangeMessages; // Return empty vector for invalid range
    }
    
    // Clamp endIndex to collection size
    if (endIndex > messageList->size()) {
        endIndex = messageList->size();
    }
    
    // Extract messages in range
    for (size_t i = startIndex; i < endIndex; i++) {
        rangeMessages.push_back((*messageList)[i]);
    }
    
    return rangeMessages;
}

/**
 * @brief Get the last N messages from the collection
 * 
 * Retrieves the most recent messages, useful for displaying
 * recent chat history. Handles cases where fewer messages
 * exist than requested.
 * 
 * @param count Number of recent messages to retrieve
 * @return Vector of most recent messages in chronological order
 * 
 * @details Recent Message Logic:
 * 1. Calculate starting index (size - count, or 0)
 * 2. Extract messages from start to end
 * 3. Return in chronological order (oldest to newest)
 * 4. Handle edge cases (empty collection, count > size)
 * 
 * @note Returns messages in chronological order (oldest first)
 * @note Returns all messages if count > collection size
 * @note Does not modify iterator position
 */
std::vector<std::string> MessageIterator::getRecentMessages(size_t count) 
{
    if (messageList == nullptr || messageList->empty() || count == 0) {
        return std::vector<std::string>();
    }
    
    size_t startIndex = 0;
    if (count < messageList->size()) {
        startIndex = messageList->size() - count;
    }
    
    return getMessagesInRange(startIndex, messageList->size());
}