#ifndef USERITERATOR_H
#define USERITERATOR_H

#include "Iterator.h"
#include "Users.h"
#include <vector>

/**
 * @file UserIterator.h
 * @brief Concrete iterator for traversing users in chat rooms
 * @author 2Amigos
 * @date 2025-09-29
 */

/**
 * @class UserIterator
 * @brief Concrete iterator implementation for traversing Users
 * 
 * Provides sequential access to users in a chat room without exposing
 * the underlying vector structure. Allows safe traversal and filtering
 * of users based on various criteria.
 */
class UserIterator : public Iterator<Users>
{
private:
    std::vector<Users*>* userList; 
    size_t currentIndex;          
    
public:
    /**
     * @brief Constructor for UserIterator
     * @param users Pointer to vector of users to iterate over
     */
    UserIterator(std::vector<Users*>* users);
    
    /**
     * @brief Destructor
     */
    virtual ~UserIterator();
    
    /**
     * @brief Check if there are more users to iterate
     * @return true if there are more users, false otherwise
     */
    virtual bool hasNext() override;
    
    /**
     * @brief Get the next user in the iteration
     * @return Pointer to the next user, nullptr if at end
     */
    virtual Users* next() override;
    
    /**
     * @brief Reset iterator to the beginning
     */
    virtual void reset() override;
    
    /**
     * @brief Get current user without advancing
     * @return Pointer to current user, nullptr if at end
     */
    virtual Users* current() override;
    
    /**
     * @brief Check if iterator is at the end
     * @return true if at end, false otherwise
     */
    virtual bool isDone() override;
    
    /**
     * @brief Get total number of users
     * @return Total user count
     */
    size_t getTotalUsers();
    
    /**
     * @brief Skip to next user with specific permission level
     * @param level Permission level to find
     * @return Pointer to user with specified level, nullptr if not found
     */
    Users* findUserWithPermissionLevel(int level);
    
    /**
     * @brief Get users by permission level (filtering functionality)
     * @param level Permission level to filter by
     * @return Vector of users with specified permission level
     */
    std::vector<Users*> getUsersByPermissionLevel(int level);
};

#endif