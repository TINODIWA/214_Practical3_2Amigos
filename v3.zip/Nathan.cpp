#include "Nathan.h"

Nathan::Nathan(ChatRoom *room) : Users(room, "Nathan") {}