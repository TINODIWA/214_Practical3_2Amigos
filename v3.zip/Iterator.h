#ifndef ITERATOR_H
#define ITERATOR_H

/**
 * @file Iterator.h
 * @brief Abstract Iterator interface for the Iterator design pattern
 * @author 2Amigos
 * @date 2025-09-29
 */

/**
 * @class Iterator
 * @brief Abstract base class for iterators in the Iterator pattern
 * 
 * Provides a way to access elements of an aggregate object sequentially
 * without exposing its underlying representation.
 * 
 * @tparam T The type of elements to iterate over
 */
template<typename T>
class Iterator
{
public:
    /**
     * @brief Virtual destructor for proper cleanup
     */
    virtual ~Iterator() = default;
    
    /**
     * @brief Check if there are more elements to iterate
     * @return true if there are more elements, false otherwise
     */
    virtual bool hasNext() = 0;
    
    /**
     * @brief Get the next element in the iteration
     * @return Pointer to the next element
     */
    virtual T* next() = 0;
    
    /**
     * @brief Reset iterator to the beginning
     */
    virtual void reset() = 0;
    
    /**
     * @brief Get current element without advancing
     * @return Pointer to current element, nullptr if at end
     */
    virtual T* current() = 0;
    
    /**
     * @brief Check if iterator is at the end
     * @return true if at end, false otherwise
     */
    virtual bool isDone() = 0;
};

#endif