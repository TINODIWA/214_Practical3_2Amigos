#include "Luyanda.h"

Luyanda::Luyanda(ChatRoom* room) : Users(room, "Luyanda"){}