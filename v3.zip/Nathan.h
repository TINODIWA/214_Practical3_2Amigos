#ifndef NATHAN_H
#define NATHAN_H

#include "Users.h"

class Nathan : public Users
{
    public:
        Nathan(ChatRoom* room);
};

#endif