#ifndef MESSAGEITERATOR_H
#define MESSAGEITERATOR_H

#include "Iterator.h"
#include <vector>
#include <string>

/**
 * @file MessageIterator.h
 * @brief Concrete iterator for traversing chat history messages
 * @author 2Amigos
 * @date 2025-09-29
 */

/**
 * @class MessageIterator
 * @brief Concrete iterator implementation for traversing chat messages
 * 
 * Provides sequential access to messages in chat history without exposing
 * the underlying vector structure. Supports both forward and reverse
 * iteration, filtering, and search capabilities.
 */
class MessageIterator : public Iterator<std::string>
{
private:
    std::vector<std::string>* messageList;  // Pointer to the message collection
    size_t currentIndex;                    // Current position in iteration
    bool reverseMode;                       // Whether to iterate in reverse
    
public:
    /**
     * @brief Constructor for MessageIterator
     * @param messages Pointer to vector of messages to iterate over
     * @param reverse Whether to iterate in reverse order (default: false)
     */
    MessageIterator(std::vector<std::string>* messages, bool reverse = false);
    
    /**
     * @brief Destructor
     */
    virtual ~MessageIterator();
    
    /**
     * @brief Check if there are more messages to iterate
     * @return true if there are more messages, false otherwise
     */
    virtual bool hasNext() override;
    
    /**
     * @brief Get the next message in the iteration
     * @return Pointer to the next message, nullptr if at end
     */
    virtual std::string* next() override;
    
    /**
     * @brief Reset iterator to the beginning (or end if reverse)
     */
    virtual void reset() override;
    
    /**
     * @brief Get current message without advancing
     * @return Pointer to current message, nullptr if at end
     */
    virtual std::string* current() override;
    
    /**
     * @brief Check if iterator is at the end
     * @return true if at end, false otherwise
     */
    virtual bool isDone() override;
    
    /**
     * @brief Get total number of messages
     * @return Total message count
     */
    size_t getTotalMessages();
    
    /**
     * @brief Switch between forward and reverse iteration
     * @param reverse true for reverse iteration, false for forward
     */
    void setReverseMode(bool reverse);
    
    /**
     * @brief Find next message containing specific text
     * @param searchText Text to search for in messages
     * @return Pointer to message containing text, nullptr if not found
     */
    std::string* findMessageContaining(const std::string& searchText);
    
    /**
     * @brief Get all messages from a specific user
     * @param username Name of user to filter messages by
     * @return Vector of messages from specified user
     */
    std::vector<std::string> getMessagesByUser(const std::string& username);
    
    /**
     * @brief Get messages within a specific range
     * @param startIndex Starting index (inclusive)
     * @param endIndex Ending index (exclusive)
     * @return Vector of messages in specified range
     */
    std::vector<std::string> getMessagesInRange(size_t startIndex, size_t endIndex);
    
    /**
     * @brief Get the last N messages
     * @param count Number of recent messages to retrieve
     * @return Vector of most recent messages
     */
    std::vector<std::string> getRecentMessages(size_t count);
};

#endif