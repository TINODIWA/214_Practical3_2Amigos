#ifndef DOG_THEME_STRATEGY_H
#define DOG_THEME_STRATEGY_H

#include "MessageProcessingStrategy.h"
#include <string>

/**
 * @brief Concrete Strategy: Technical / algorithm focused formatting
 */
class DogThemeStrategy : public MessageProcessingStrategy {
public:
    virtual std::string processMessage(const std::string& rawMessage, Users* fromUser, const std::string& roomName);
};

#endif
