#include "CatThemeStrategy.h"
#include "Users.h"
#include <ctime>

std::string CatThemeStrategy::processMessage(const std::string& rawMessage, Users* fromUser, const std::string& roomName) {
    std::time_t t = std::time(nullptr);
    char buf[20];
    std::strftime(buf, sizeof(buf), "%H:%M:%S", std::localtime(&t));

    std::string decorated = "[" + std::string(buf) + "] [" + roomName + "] 🐾 " + fromUser->getName() + ": " + rawMessage;
    if (rawMessage.find("help") != std::string::npos || rawMessage.find("debug") != std::string::npos) {
        decorated += "   (The pride will help!)";
    }
    return decorated;
}
