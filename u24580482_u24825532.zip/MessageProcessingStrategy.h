#ifndef MESSAGE_PROCESSING_STRATEGY_H
#define MESSAGE_PROCESSING_STRATEGY_H

#include <string>

class Users; // forward declaration

/**
 * @file MessageProcessingStrategy.h
 * @brief Strategy interface for customizable message preprocessing (Strategy Pattern)
 *
 * The Strategy pattern lets ChatRoom delegate step 3 (preprocessMessage) of the
 * Template Method workflow to interchangeable strategy objects. This supports
 * runtime switching of message formatting / enrichment rules without modifying
 * ChatRoom or concrete room subclasses.
 */
class MessageProcessingStrategy {
public:
    virtual ~MessageProcessingStrategy() = default;

    /**
     * @brief Process / transform an outgoing message before broadcast
     * @param rawMessage Original user-entered text (unmodified)
     * @param fromUser   Sender (can be used for personalization / permissions)
     * @param roomName   Name of the room (for contextual tags)
     * @return Transformed / formatted message string ready for broadcast
     */
    virtual std::string processMessage(const std::string& rawMessage, Users* fromUser, const std::string& roomName) = 0;
};

#endif
