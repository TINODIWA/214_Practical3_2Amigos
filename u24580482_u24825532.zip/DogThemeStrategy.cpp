#include "DogThemeStrategy.h"
#include "Users.h"
#include <ctime>

std::string DogThemeStrategy::processMessage(const std::string& rawMessage, Users* fromUser, const std::string& roomName) {
    std::time_t t = std::time(nullptr);
    char buf[20];
    std::strftime(buf, sizeof(buf), "%H:%M:%S", std::localtime(&t));

    std::string base = "[" + std::string(buf) + "] [" + roomName + "]  " + fromUser->getName() + ": " + rawMessage;

    if (rawMessage.find("O(") != std::string::npos) {
        base += " <TAG:Complexity>";
    }
    if (rawMessage.find("optimize") != std::string::npos || rawMessage.find("efficient") != std::string::npos) {
        base = base + " <TAG:Performance>";
    }
    if (rawMessage.find("recursive") != std::string::npos) {
        base = base + " <TAG:Recursion>";
    }
    if (rawMessage.find("tree") != std::string::npos || rawMessage.find("graph") != std::string::npos) {
        base = base + " <TAG:DataStructure>";
    }

    return base;
}