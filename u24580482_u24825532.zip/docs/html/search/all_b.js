var searchData=
[
  ['nathan_53',['Nathan',['../classNathan.html',1,'']]],
  ['next_54',['next',['../classIterator.html#a2957e4971d1c4440f718814123b83a72',1,'Iterator::next()'],['../classMessageIterator.html#acc5dd84793695e585ea65b7fbb9fcf92',1,'MessageIterator::next()'],['../classUserIterator.html#af43fe2ed3fc6979b4671a719ce1dfb92',1,'UserIterator::next()']]]
];
