var searchData=
[
  ['incrementmessagecount_39',['incrementMessageCount',['../classUsers.html#a43d334c0c8c8b12ea0d544c22546000c',1,'Users']]],
  ['isdone_40',['isDone',['../classIterator.html#a8e7b414c641f4f0838ff8bd6ba954b7a',1,'Iterator::isDone()'],['../classMessageIterator.html#a665805bc6a7d49cb67de2b5114d44e7a',1,'MessageIterator::isDone()'],['../classUserIterator.html#a0deba5da4c0a7a031f52fbb4e1b68ce7',1,'UserIterator::isDone()']]],
  ['ismuteduser_41',['isMutedUser',['../classUsers.html#a7766161fa21d3b43c381ffa086fa0631',1,'Users']]],
  ['iterator_42',['Iterator',['../classIterator.html',1,'']]],
  ['iterator_2eh_43',['Iterator.h',['../Iterator_8h.html',1,'']]],
  ['iterator_3c_20std_3a_3astring_20_3e_44',['Iterator&lt; std::string &gt;',['../classIterator.html',1,'']]],
  ['iterator_3c_20users_20_3e_45',['Iterator&lt; Users &gt;',['../classIterator.html',1,'']]]
];
