var searchData=
[
  ['receive_164',['receive',['../classUsers.html#aa3e36c8f4a560087f87a09869dd412cf',1,'Users']]],
  ['registeruser_165',['registerUser',['../classChatRoom.html#af5841c571486016ff677dd9e0fa2d355',1,'ChatRoom::registerUser()'],['../classCtrlCat.html#a3837209f11c6f8dbb303ced0a87ceacb',1,'CtrlCat::registerUser()'],['../classDogorithm.html#a108579c735b4bd98f468bae41954c12c',1,'Dogorithm::registerUser()']]],
  ['removeuser_166',['removeUser',['../classChatRoom.html#a3fe20246c0407eae1f127f4a6194fd62',1,'ChatRoom::removeUser()'],['../classCtrlCat.html#a0c67805b860386067f8686f3c43cf142',1,'CtrlCat::removeUser()'],['../classDogorithm.html#afb860542196d2e1a25bbd3ef6e45dd89',1,'Dogorithm::removeUser()']]],
  ['reset_167',['reset',['../classIterator.html#a5c284e826d7d2ad400c10167ba643199',1,'Iterator::reset()'],['../classMessageIterator.html#a7f1f2e10fe0af3dd75ce208f35d860c1',1,'MessageIterator::reset()'],['../classUserIterator.html#a2434f9f8d31fb5d37611893636dc16c6',1,'UserIterator::reset()']]]
];
