var searchData=
[
  ['findmessagecontaining_23',['findMessageContaining',['../classMessageIterator.html#abb93cc49417e4a00db44f2730f34fc72',1,'MessageIterator']]],
  ['finduserwithpermissionlevel_24',['findUserWithPermissionLevel',['../classUserIterator.html#afa36423ae1446eda52286dc083553749',1,'UserIterator']]]
];
