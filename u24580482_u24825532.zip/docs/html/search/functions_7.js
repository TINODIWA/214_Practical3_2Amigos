var searchData=
[
  ['hasnext_154',['hasNext',['../classIterator.html#ac739493f5b0ef3333abf23c551e416f0',1,'Iterator::hasNext()'],['../classMessageIterator.html#a5f284cecaceb46e55bd223360a894801',1,'MessageIterator::hasNext()'],['../classUserIterator.html#a45f9ba1340aa1c006e7535ca59fbeaba',1,'UserIterator::hasNext()']]]
];
