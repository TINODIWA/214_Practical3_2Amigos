var searchData=
[
  ['logactivity_158',['logActivity',['../classChatRoom.html#acf77682301445d3f421c28cbf0641e0a',1,'ChatRoom::logActivity()'],['../classCtrlCat.html#a6ea0c19ee56d0809f209b472bdb6db14',1,'CtrlCat::logActivity()'],['../classDogorithm.html#aa6ead85270a60203264385a9f210e648',1,'Dogorithm::logActivity()']]]
];
