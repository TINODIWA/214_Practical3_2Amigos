#ifndef LUYANDA_H
#define LUYANDA_H

#include "Users.h"

class Luyanda : public Users
{
    public:
        Luyanda(ChatRoom* room);
};

#endif