#include "UserIterator.h"

/**
 * @file UserIterator.cpp
 * @brief Implementation of UserIterator concrete iterator
 * @author 2Amigos
 * @date 2025-09-29
 */

/**
 * @brief Constructor for UserIterator
 * 
 * Initializes the iterator with a pointer to the user collection
 * and sets the current index to the beginning of the collection.
 * 
 * @param users Pointer to vector of Users to iterate over
 * 
 * @note Performs null pointer validation for safety
 * @note Sets currentIndex to 0 for iteration start
 */
UserIterator::UserIterator(std::vector<Users*>* users) 
    : userList(users), currentIndex(0) 
{
    if (userList == nullptr) {
        userList = new std::vector<Users*>(); 
        ownsUserList = true;  // We created it, so we own it
    } else {
        ownsUserList = false; // We don't own the external vector
    }
}

/**
 * @brief Destructor for UserIterator
 * 
 * Cleans up resources. Note that this iterator does not own the user
 * collection, so it doesn't delete the vector itself, only cleans up
 * any internally created resources.
 */
UserIterator::~UserIterator() 
{
    // Only delete the vector if we created it ourselves
    if (ownsUserList && userList != nullptr) {
        delete userList;
        userList = nullptr;
    }
}

/**
 * @brief Check if there are more users to iterate over
 * 
 * Determines if the iterator has reached the end of the collection
 * by comparing current index with the collection size.
 * 
 * @return true if there are more users to iterate, false if at end
 * 
 * @note Safe against null userList pointer
 * @note Uses size_t comparison to avoid signed/unsigned warnings
 */
bool UserIterator::hasNext() 
{
    if (userList == nullptr) {
        return false;
    }
    return currentIndex < userList->size();
}

/**
 * @brief Get the next user and advance the iterator
 * 
 * Returns the current user and advances the internal index to the
 * next position. Provides bounds checking for safe access.
 * 
 * @return Pointer to the next Users object, nullptr if at end
 * 
 * @details Iterator Advancement:
 * 1. Check bounds and null pointer safety
 * 2. Get current user at currentIndex
 * 3. Increment currentIndex for next call
 * 4. Return the user pointer
 * 
 * @note Automatically advances iterator position
 * @note Returns nullptr when iterator reaches end
 * @note Thread-safe for read operations
 */
Users* UserIterator::next() 
{
    if (!hasNext()) {
        return nullptr;
    }
    
    Users* user = (*userList)[currentIndex];
    currentIndex = currentIndex + 1;
    return user;
}

/**
 * @brief Reset iterator to the beginning of the collection
 * 
 * Resets the current index to 0, allowing the iterator to start
 * over from the beginning of the user collection.
 * 
 * @note Allows reusing the same iterator multiple times
 * @note Safe to call at any point during iteration
 * @note Commonly used for multiple passes over the same data
 */
void UserIterator::reset() 
{
    currentIndex = 0;
}

/**
 * @brief Get current user without advancing the iterator
 * 
 * Returns the user at the current position without modifying the
 * iterator state. Useful for examining the current element without
 * consuming it.
 * 
 * @return Pointer to current Users object, nullptr if at end
 * 
 * @note Does not advance the iterator position
 * @note Returns nullptr when iterator is at end
 * @note Useful for peek operations
 */
Users* UserIterator::current() 
{
    if (!hasNext()) {
        return nullptr;
    }
    
    return (*userList)[currentIndex];
}

/**
 * @brief Check if iterator has reached the end
 * 
 * Determines if the iterator is at the end of the collection.
 * This is the opposite of hasNext() and provides a different
 * semantic interface for iteration control.
 * 
 * @return true if iterator is at end, false if more elements exist
 * 
 * @note Logically equivalent to !hasNext()
 * @note Provides semantic clarity in certain iteration patterns
 */
bool UserIterator::isDone() 
{
    return !hasNext();
}

/**
 * @brief Get total number of users in the collection
 * 
 * Returns the size of the underlying user collection without
 * affecting the iterator state. Useful for progress tracking
 * and collection size queries.
 * 
 * @return Total number of users in the collection
 * 
 * @note Does not modify iterator state
 * @note Returns 0 for null collections
 * @note Useful for iteration progress calculation
 */
size_t UserIterator::getTotalUsers() 
{
    if (userList == nullptr) {
        return 0;
    }
    return userList->size();
}

/**
 * @brief Find next user with specific permission level
 * 
 * Advances the iterator to find the next user with the specified
 * permission level. Provides filtering capability during iteration.
 * 
 * @param level Permission level to search for (1-4)
 * @return Pointer to user with specified level, nullptr if not found
 * 
 * @details Search Process:
 * 1. Continue from current position
 * 2. Check each user's permission level
 * 3. Return first match found
 * 4. Update iterator position to found user
 * 5. Return nullptr if no match found
 * 
 * @note Modifies iterator position to found user
 * @note Returns nullptr if no user with specified level found
 * @note Useful for permission-based filtering during iteration
 */
Users* UserIterator::findUserWithPermissionLevel(int level) 
{
    while (hasNext()) {
        Users* user = current();
        if (user != nullptr && user->getPermissionLevel() == level) {
            next();
            return user;
        }
        next(); 
    }
    return nullptr;
}

/**
 * @brief Get all users with specific permission level
 * 
 * Performs a complete pass through the collection to find all users
 * with the specified permission level. Does not modify iterator state.
 * 
 * @param level Permission level to filter by (1-4)
 * @return Vector containing all users with specified permission level
 * 
 * @details Filtering Process:
 * 1. Save current iterator position
 * 2. Reset iterator to beginning
 * 3. Traverse entire collection
 * 4. Collect all matching users
 * 5. Restore original iterator position
 * 6. Return collected users
 * 
 * @note Does not modify iterator position
 * @note Returns empty vector if no matches found
 * @note Performs complete collection traversal
 * @note Restores iterator state after operation
 */
std::vector<Users*> UserIterator::getUsersByPermissionLevel(int level) 
{
    std::vector<Users*> filteredUsers;
    
    size_t originalIndex = currentIndex;
    
    reset();
    while (hasNext()) {
        Users* user = next();
        if (user != nullptr && user->getPermissionLevel() == level) {
            filteredUsers.push_back(user);
        }
    }
    
    currentIndex = originalIndex;
    
    return filteredUsers;
}