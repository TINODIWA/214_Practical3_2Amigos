var searchData=
[
  ['validatemessage_179',['validateMessage',['../classChatRoom.html#a645f02c9cacdb364f1f6f46d0f57f4c6',1,'ChatRoom::validateMessage()'],['../classCtrlCat.html#abe560f0f9c5946aee5fd33c6abac9c98',1,'CtrlCat::validateMessage()'],['../classDogorithm.html#a6a186d1d281165ce29cf7d8626b54592',1,'Dogorithm::validateMessage()']]]
];
