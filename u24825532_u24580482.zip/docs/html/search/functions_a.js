var searchData=
[
  ['messageiterator_159',['MessageIterator',['../classMessageIterator.html#a2d6c39d66f2f437327f011fc5e4892d2',1,'MessageIterator']]]
];
