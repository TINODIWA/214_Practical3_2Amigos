var searchData=
[
  ['luyanda_99',['Luyanda',['../classLuyanda.html',1,'']]]
];
