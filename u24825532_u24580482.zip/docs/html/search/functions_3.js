var searchData=
[
  ['dogorithm_136',['Dogorithm',['../classDogorithm.html#a75a033b9aaab1ab32dc56cbcc9531e60',1,'Dogorithm']]]
];
