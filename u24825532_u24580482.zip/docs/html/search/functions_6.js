var searchData=
[
  ['getchathistory_141',['getChatHistory',['../classChatRoom.html#a6251063174446b6dcc7fb663d7802a68',1,'ChatRoom']]],
  ['getmessagecount_142',['getMessageCount',['../classUsers.html#a1351fb7ad2eccded49497437b6ff75f1',1,'Users']]],
  ['getmessageprocessingstrategy_143',['getMessageProcessingStrategy',['../classChatRoom.html#ad686b41cac82d74342c819027cf4c3b9',1,'ChatRoom']]],
  ['getmessagesbyuser_144',['getMessagesByUser',['../classMessageIterator.html#a1711b32f679fc56675d903a692646167',1,'MessageIterator']]],
  ['getmessagesinrange_145',['getMessagesInRange',['../classMessageIterator.html#a10393bc4ae3ebb4a5311cc9b155ebfa3',1,'MessageIterator']]],
  ['getname_146',['getName',['../classUsers.html#ab648a02df271043c51596d8cd78aa0ff',1,'Users']]],
  ['getpermissionlevel_147',['getPermissionLevel',['../classUsers.html#af9e64765262783284c024cbe2885a70a',1,'Users']]],
  ['getrecentmessages_148',['getRecentMessages',['../classMessageIterator.html#a0900424a19925b5aa8372dead0c95308',1,'MessageIterator']]],
  ['getroomname_149',['getRoomName',['../classChatRoom.html#a3123e20d93177e67a35fcc9ed4e396d4',1,'ChatRoom::getRoomName()'],['../classCtrlCat.html#ac873716c7290fd2fa9e66fe144feebc0',1,'CtrlCat::getRoomName()'],['../classDogorithm.html#a17ac07cea1cf21ba2e3728b307ac9d64',1,'Dogorithm::getRoomName()']]],
  ['gettotalmessages_150',['getTotalMessages',['../classMessageIterator.html#abcc45dd416c88af78a74047633ebec69',1,'MessageIterator']]],
  ['gettotalusers_151',['getTotalUsers',['../classUserIterator.html#a985588e1876ed40be2b4706c6944da07',1,'UserIterator']]],
  ['getusers_152',['getUsers',['../classChatRoom.html#a4092e4526216630ee4120af1fc1be9db',1,'ChatRoom']]],
  ['getusersbypermissionlevel_153',['getUsersByPermissionLevel',['../classUserIterator.html#a44aa93e444be89254772ffb0ecf9b82e',1,'UserIterator']]]
];
