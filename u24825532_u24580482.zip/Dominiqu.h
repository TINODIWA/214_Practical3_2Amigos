#ifndef DOMINIQU_H
#define DOMINIQU_H

#include "Users.h"

class Dominiqu : public Users
{
    public:
        Dominiqu(ChatRoom* room);
};

#endif